ドラッグアンドドロップ＆配置アプリ<br>
pip install tkinterdnd2をインストールしてください。<br>
pip install Pillowをインストールしてください。<br>
C:\Users\0314AM\AppData\Local\Programs\Python\Python39\tcl　にtkdndファイルを配置してください。

〇デスクトップかフォルダーから画像ファイルをドラッグアンドドロップしてください
